"use strict";

/**
 * Wrap an async route handler so rejected promises are forwarded to the
 * centralised Express error handler instead of crashing the process.
 */
module.exports = function asyncHandler(fn) {
  return function wrapped(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};
